import './StarBg.css';

const StarBg = () => {
  return (
    <div className="stars-animate stars-animate-sticky-top fixed inset-0 z-0">
      <div className="bg-stars"></div>
      <div className="bg-stars2"></div>
    </div>
  );
};

export default StarBg;
